import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Header } from "@/components/header";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product, InsertProduct, User, SiteSettings } from "@shared/schema";
import { CURRENCIES, formatPrice, type CurrencyCode } from "@shared/currency";
import { ArrowLeft, Plus, Pencil, Trash2, Package, Settings, Upload, X, Users, Shield, Palette, Image, Search, Sparkles } from "lucide-react";
import { queryClient, apiRequest, getAuthToken } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";

type SafeUser = Omit<User, "password">;

interface UserFormData {
  username: string;
  password: string;
  displayName: string;
  role: "owner" | "employee";
}

function UserForm({
  user,
  onSubmit,
  onCancel,
  isLoading,
  currentUserId,
}: {
  user?: SafeUser;
  onSubmit: (data: UserFormData) => void;
  onCancel: () => void;
  isLoading: boolean;
  currentUserId?: string;
}) {
  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<UserFormData>({
    defaultValues: user
      ? {
          username: user.username,
          password: "",
          displayName: user.displayName || "",
          role: user.role as "owner" | "employee",
        }
      : {
          username: "",
          password: "",
          displayName: "",
          role: "employee",
        },
  });

  const selectedRole = watch("role");

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="username">Username *</Label>
          <Input
            id="username"
            {...register("username", { required: "Username is required", minLength: { value: 3, message: "Username must be at least 3 characters" } })}
            placeholder="Enter username"
            data-testid="input-user-username"
          />
          {errors.username && (
            <p className="text-sm text-destructive">{errors.username.message}</p>
          )}
        </div>

        <div className="grid gap-2">
          <Label htmlFor="password">{user ? "New Password (leave empty to keep current)" : "Password *"}</Label>
          <Input
            id="password"
            type="password"
            {...register("password", user ? {} : { required: "Password is required", minLength: { value: 6, message: "Password must be at least 6 characters" } })}
            placeholder={user ? "Leave empty to keep current" : "Enter password"}
            data-testid="input-user-password"
          />
          {errors.password && (
            <p className="text-sm text-destructive">{errors.password.message}</p>
          )}
        </div>

        <div className="grid gap-2">
          <Label htmlFor="displayName">Display Name</Label>
          <Input
            id="displayName"
            {...register("displayName")}
            placeholder="Enter display name"
            data-testid="input-user-displayname"
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="role">Role *</Label>
          <Select
            value={selectedRole}
            onValueChange={(value: "owner" | "employee") => setValue("role", value)}
          >
            <SelectTrigger data-testid="select-user-role">
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="owner" data-testid="select-role-owner">Owner (Full Access)</SelectItem>
              <SelectItem value="employee" data-testid="select-role-employee">Employee (View Only)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <DialogFooter className="gap-2">
        <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel-user">
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} data-testid="button-save-user">
          {isLoading ? "Saving..." : user ? "Update User" : "Add User"}
        </Button>
      </DialogFooter>
    </form>
  );
}

interface ProductFormData {
  name: string;
  description: string;
  imageUrl: string;
  category: string;
  barcode: string;
  currency: "USD" | "IQD";
  regularPrice: number;
  finalPrice: number;
  inStock: number;
}

function ProductForm({
  product,
  onSubmit,
  onCancel,
  isLoading,
}: {
  product?: Product;
  onSubmit: (data: ProductFormData) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<ProductFormData>({
    defaultValues: product
      ? {
          name: product.name,
          description: product.description || "",
          imageUrl: product.imageUrl || "",
          category: product.category || "",
          barcode: product.barcode || "",
          currency: (product.currency as "USD" | "IQD") || "USD",
          regularPrice: product.regularPrice,
          finalPrice: product.finalPrice,
          inStock: product.inStock || 1,
        }
      : {
          name: "",
          description: "",
          imageUrl: "",
          category: "",
          barcode: "",
          currency: "USD",
          regularPrice: 0,
          finalPrice: 0,
          inStock: 10,
        },
  });

  const selectedCurrency = watch("currency");

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isLookingUp, setIsLookingUp] = useState(false);
  const currentImageUrl = watch("imageUrl");
  const currentBarcode = watch("barcode");

  const handleBarcodeLookup = async () => {
    if (!currentBarcode || currentBarcode.trim() === "") {
      toast({
        title: "Enter barcode first",
        description: "Please enter a barcode to lookup",
        variant: "destructive",
      });
      return;
    }

    setIsLookingUp(true);
    try {
      const token = getAuthToken();
      const headers: any = { "Content-Type": "application/json" };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch("/api/barcode-lookup", {
        method: "POST",
        headers,
        body: JSON.stringify({ barcode: currentBarcode.trim() }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Lookup failed");
      }

      const data = await response.json();
      
      // Auto-fill form fields with returned data
      if (data.name) setValue("name", data.name);
      if (data.description) setValue("description", data.description);
      if (data.category) setValue("category", data.category);
      if (data.imageUrl) setValue("imageUrl", data.imageUrl);

      toast({
        title: "Product found!",
        description: `AI found: ${data.name || "Product information"}`,
      });
    } catch (error) {
      console.error("Barcode lookup error:", error);
      toast({
        title: "Lookup failed",
        description: error instanceof Error ? error.message : "Could not lookup barcode",
        variant: "destructive",
      });
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("image", file);

      const token = getAuthToken();
      const headers: any = {};
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Upload failed");
      }

      const data = await response.json();
      setValue("imageUrl", data.imageUrl);
      toast({
        title: "Image uploaded",
        description: "Product image has been uploaded successfully.",
      });
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error?.message || "Failed to upload image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const clearImage = () => {
    setValue("imageUrl", "");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="name">Product Name *</Label>
          <Input
            id="name"
            {...register("name", { required: "Name is required" })}
            placeholder="iPhone 15 Pro"
            data-testid="input-product-name"
          />
          {errors.name && (
            <p className="text-sm text-destructive">{errors.name.message}</p>
          )}
        </div>

        <div className="grid gap-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            {...register("description")}
            placeholder="Product description..."
            rows={3}
            data-testid="input-product-description"
          />
        </div>

        <div className="grid gap-2">
          <Label>Product Image</Label>
          <input
            type="hidden"
            {...register("imageUrl")}
          />
          <div className="flex flex-col gap-3">
            {currentImageUrl ? (
              <div className="relative w-full h-40 bg-muted rounded-lg overflow-hidden">
                <img
                  src={currentImageUrl}
                  alt="Product preview"
                  className="w-full h-full object-cover"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8"
                  onClick={clearImage}
                  data-testid="button-remove-image"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div
                className="w-full h-40 bg-muted rounded-lg border-2 border-dashed border-muted-foreground/25 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">
                  {isUploading ? "Uploading..." : "Click to upload image"}
                </span>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              data-testid="input-product-image"
            />
            {!currentImageUrl && (
              <Button
                type="button"
                variant="outline"
                className="gap-2"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                data-testid="button-upload-image"
              >
                <Upload className="h-4 w-4" />
                {isUploading ? "Uploading..." : "Upload Image"}
              </Button>
            )}
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="category">Category</Label>
          <Input
            id="category"
            {...register("category")}
            placeholder="Smartphones"
            data-testid="input-product-category"
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="barcode">Barcode (AI Auto-fill)</Label>
          <div className="flex gap-2">
            <Input
              id="barcode"
              {...register("barcode")}
              placeholder="Enter barcode and click AI Lookup"
              data-testid="input-product-barcode"
              className="flex-1"
            />
            <Button
              type="button"
              variant="secondary"
              onClick={handleBarcodeLookup}
              disabled={isLookingUp || !currentBarcode}
              className="gap-2 whitespace-nowrap"
              data-testid="button-barcode-lookup"
            >
              <Sparkles className="h-4 w-4" />
              {isLookingUp ? "Looking up..." : "AI Lookup"}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Enter a barcode and click AI Lookup to auto-fill product details and image
          </p>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="currency">Currency *</Label>
          <Select
            value={selectedCurrency}
            onValueChange={(value: "USD" | "IQD") => setValue("currency", value)}
          >
            <SelectTrigger data-testid="select-product-currency">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD" data-testid="select-currency-usd">
                $ - US Dollar (USD)
              </SelectItem>
              <SelectItem value="IQD" data-testid="select-currency-iqd">
                د.ع - Iraqi Dinar (IQD)
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label htmlFor="regularPrice">Regular Price ({CURRENCIES[selectedCurrency].symbol}) *</Label>
            <Input
              id="regularPrice"
              type="number"
              step="0.01"
              {...register("regularPrice", {
                required: "Regular price is required",
                valueAsNumber: true,
                min: { value: 0.01, message: "Price must be positive" },
              })}
              placeholder={selectedCurrency === "USD" ? "999.99" : "1500000"}
              data-testid="input-product-regular-price"
            />
            {errors.regularPrice && (
              <p className="text-sm text-destructive">{errors.regularPrice.message}</p>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="finalPrice">Final Price ({CURRENCIES[selectedCurrency].symbol}) *</Label>
            <Input
              id="finalPrice"
              type="number"
              step="0.01"
              {...register("finalPrice", {
                required: "Final price is required",
                valueAsNumber: true,
                min: { value: 0.01, message: "Price must be positive" },
              })}
              placeholder={selectedCurrency === "USD" ? "899.99" : "1350000"}
              data-testid="input-product-final-price"
            />
            {errors.finalPrice && (
              <p className="text-sm text-destructive">{errors.finalPrice.message}</p>
            )}
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="inStock">Stock Quantity</Label>
          <Input
            id="inStock"
            type="number"
            {...register("inStock", {
              valueAsNumber: true,
              min: { value: 0, message: "Stock cannot be negative" },
            })}
            placeholder="10"
            data-testid="input-product-stock"
          />
        </div>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} data-testid="button-save-product">
          {isLoading ? "Saving..." : product ? "Update Product" : "Add Product"}
        </Button>
      </DialogFooter>
    </form>
  );
}

export default function AdminPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("products");
  
  // Product state
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProductId, setDeletingProductId] = useState<number | null>(null);
  const [productSearchQuery, setProductSearchQuery] = useState("");
  const [editingImageProductId, setEditingImageProductId] = useState<number | null>(null);
  const [editingImageUrl, setEditingImageUrl] = useState("");
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingProductImage, setIsUploadingProductImage] = useState(false);
  
  // User state
  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<SafeUser | null>(null);
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);

  // Website settings state
  const [primaryColor, setPrimaryColor] = useState("#8B0000");
  const [backgroundColor, setBackgroundColor] = useState("#0A0A0A");
  const [accentColor, setAccentColor] = useState("#DC2626");
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const settingsInitialized = useRef(false);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery<SafeUser[]>({
    queryKey: ["/api/users"],
  });

  const { data: siteSettings, isLoading: isLoadingSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });

  // Update local state when settings load - must be in useEffect to avoid render-time setState
  useEffect(() => {
    if (siteSettings && !settingsInitialized.current) {
      setPrimaryColor(siteSettings.primaryColor || "#8B0000");
      setBackgroundColor(siteSettings.backgroundColor || "#0A0A0A");
      setAccentColor(siteSettings.accentColor || "#DC2626");
      settingsInitialized.current = true;
    }
  }, [siteSettings]);

  // Only owners can access admin page
  if (!user || user.role !== "owner") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        {user && <Header user={user} />}
        <main className="flex-1 container mx-auto px-4 md:px-8 py-8">
          <Card className="max-w-md mx-auto">
            <CardContent className="p-8 flex flex-col items-center text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center">
                <Settings className="h-8 w-8 text-destructive" />
              </div>
              <h3 className="text-xl font-semibold">Access Denied</h3>
              <p className="text-muted-foreground">
                Only store owners can access the admin dashboard.
              </p>
              <Link href="/">
                <Button className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Store
                </Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const createProductMutation = useMutation({
    mutationFn: async (data: ProductFormData) => {
      return apiRequest("POST", "/api/products", data);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/products"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/products"], refetchType: "all" });
      setIsAddDialogOpen(false);
      toast({
        title: "Product created",
        description: "The product has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create product.",
        variant: "destructive",
      });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: ProductFormData }) => {
      return apiRequest("PATCH", `/api/products/${id}`, data);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/products"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/products"], refetchType: "all" });
      setEditingProduct(null);
      toast({
        title: "Product updated",
        description: "The product has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update product.",
        variant: "destructive",
      });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/products"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/products"], refetchType: "all" });
      setDeletingProductId(null);
      toast({
        title: "Product deleted",
        description: "The product has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete product.",
        variant: "destructive",
      });
    },
  });

  // User mutations
  const createUserMutation = useMutation({
    mutationFn: async (data: UserFormData) => {
      const trimmedPassword = data.password?.trim();
      if (!trimmedPassword || trimmedPassword.length < 6) {
        throw new Error("Password must be at least 6 characters");
      }
      const payload = { ...data, password: trimmedPassword };
      return apiRequest("POST", "/api/users", payload);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/users"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/users"], refetchType: "all" });
      setIsAddUserDialogOpen(false);
      toast({
        title: "User created",
        description: "The user has been added successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to create user.",
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<UserFormData> }) => {
      const payload: any = { ...data };
      const trimmedPassword = payload.password?.trim();
      if (trimmedPassword) {
        if (trimmedPassword.length < 6) {
          throw new Error("Password must be at least 6 characters");
        }
        payload.password = trimmedPassword;
      } else {
        delete payload.password;
      }
      return apiRequest("PATCH", `/api/users/${id}`, payload);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/users"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/users"], refetchType: "all" });
      setEditingUser(null);
      toast({
        title: "User updated",
        description: "The user has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to update user.",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/users"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/users"], refetchType: "all" });
      setDeletingUserId(null);
      toast({
        title: "User deleted",
        description: "The user has been removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to delete user.",
        variant: "destructive",
      });
    },
  });

  // Site settings mutations
  const updateSettingsMutation = useMutation({
    mutationFn: async (settings: { primaryColor?: string; backgroundColor?: string; accentColor?: string }) => {
      return apiRequest("PATCH", "/api/site-settings", settings);
    },
    onSuccess: async () => {
      queryClient.removeQueries({ queryKey: ["/api/site-settings"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/site-settings"], refetchType: "all" });
      toast({
        title: "Settings updated",
        description: "Website colors have been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to update settings.",
        variant: "destructive",
      });
    },
  });

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingLogo(true);
    try {
      const formData = new FormData();
      formData.append("logo", file);

      const token = getAuthToken();
      const headers: any = {};
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch("/api/upload-logo", {
        method: "POST",
        body: formData,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Upload failed");
      }

      queryClient.removeQueries({ queryKey: ["/api/site-settings"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/site-settings"], refetchType: "all" });
      
      toast({
        title: "Logo updated",
        description: "Website logo has been updated successfully.",
      });
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error?.message || "Failed to upload logo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploadingLogo(false);
      if (logoInputRef.current) {
        logoInputRef.current.value = "";
      }
    }
  };

  const handleSaveColors = () => {
    updateSettingsMutation.mutate({
      primaryColor,
      backgroundColor,
      accentColor,
    });
  };

  const handleProductImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingProductImage(true);
    try {
      const formData = new FormData();
      formData.append("image", file);

      const token = getAuthToken();
      const headers: any = {};
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Upload failed");
      }

      const data = await response.json();
      setEditingImageUrl(data.imageUrl);
      toast({
        title: "Image uploaded",
        description: "Click Save to apply changes.",
      });
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error?.message || "Failed to upload image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploadingProductImage(false);
    }
  };

  const handleSaveProductImage = () => {
    if (editingImageProductId !== null) {
      updateProductMutation.mutate({
        id: editingImageProductId,
        data: {
          name: products?.find(p => p.id === editingImageProductId)?.name || "",
          description: products?.find(p => p.id === editingImageProductId)?.description || "",
          imageUrl: editingImageUrl,
          category: products?.find(p => p.id === editingImageProductId)?.category || "",
          barcode: products?.find(p => p.id === editingImageProductId)?.barcode || "",
          currency: (products?.find(p => p.id === editingImageProductId)?.currency as "USD" | "IQD") || "USD",
          regularPrice: products?.find(p => p.id === editingImageProductId)?.regularPrice || 0,
          finalPrice: products?.find(p => p.id === editingImageProductId)?.finalPrice || 0,
          inStock: products?.find(p => p.id === editingImageProductId)?.inStock || 0,
        }
      });
      setEditingImageProductId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header user={user} />
      
      <main className="flex-1 container mx-auto px-4 md:px-8 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Link href="/">
            <Button variant="ghost" className="gap-2" data-testid="button-back">
              <ArrowLeft className="h-4 w-4" />
              Back to Store
            </Button>
          </Link>
        </div>

        <div className="flex items-center gap-3 mb-8">
          <Settings className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold" data-testid="text-admin-title">
            Admin Dashboard
          </h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-lg grid-cols-3">
            <TabsTrigger value="products" className="gap-2" data-testid="tab-products">
              <Package className="h-4 w-4" />
              Products
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2" data-testid="tab-users">
              <Users className="h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="website" className="gap-2" data-testid="tab-website">
              <Palette className="h-4 w-4" />
              Website
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Product Management</h2>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2" data-testid="button-add-product">
                    <Plus className="h-4 w-4" />
                    Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                    <DialogDescription>
                      Fill in the details to add a new product to your store.
                    </DialogDescription>
                  </DialogHeader>
                  <ProductForm
                    onSubmit={(data) => createProductMutation.mutate(data)}
                    onCancel={() => setIsAddDialogOpen(false)}
                    isLoading={createProductMutation.isPending}
                  />
                </DialogContent>
              </Dialog>
            </div>

            <Input
              placeholder="Search products by name, category, or barcode..."
              value={productSearchQuery}
              onChange={(e) => setProductSearchQuery(e.target.value)}
              data-testid="input-product-search"
              className="max-w-md"
            />

            {isLoading ? (
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : !products || products.length === 0 ? (
              <Card className="max-w-md mx-auto">
                <CardContent className="p-8 flex flex-col items-center text-center space-y-4">
                  <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                    <Package className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold">No Products Yet</h3>
                  <p className="text-muted-foreground">
                    Add your first product to start selling.
                  </p>
                  <Button onClick={() => setIsAddDialogOpen(true)} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add Product
                  </Button>
                </CardContent>
              </Card>
            ) : (() => {
              const filteredProducts = productSearchQuery.trim()
                ? products.filter((product) => {
                    const query = productSearchQuery.toLowerCase();
                    return (
                      product.name.toLowerCase().includes(query) ||
                      (product.category && product.category.toLowerCase().includes(query)) ||
                      (product.barcode && product.barcode.toLowerCase().includes(query))
                    );
                  })
                : products;

              return filteredProducts.length === 0 ? (
                <Card className="max-w-md mx-auto">
                  <CardContent className="p-8 flex flex-col items-center text-center space-y-4">
                    <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                      <Package className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-xl font-semibold">No Products Found</h3>
                    <p className="text-muted-foreground">
                      Try adjusting your search terms.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Products ({filteredProducts.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Barcode</TableHead>
                          <TableHead>Currency</TableHead>
                          <TableHead>Regular Price</TableHead>
                          <TableHead>Final Price</TableHead>
                          <TableHead>Stock</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredProducts.map((product) => {
                        const discountPercent = Math.round(
                          ((product.regularPrice - product.finalPrice) / product.regularPrice) * 100
                        );
                        const productCurrency = product.currency || "USD";
                        return (
                          <TableRow key={product.id} data-testid={`product-row-${product.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 bg-muted rounded-md overflow-hidden shrink-0">
                                  {product.imageUrl ? (
                                    <img
                                      src={product.imageUrl}
                                      alt={product.name}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center">
                                      <Package className="h-4 w-4 text-muted-foreground/40" />
                                    </div>
                                  )}
                                </div>
                                <span className="font-medium">{product.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              {product.category && (
                                <Badge variant="outline">{product.category}</Badge>
                              )}
                            </TableCell>
                            <TableCell data-testid={`text-barcode-${product.id}`}>
                              {product.barcode ? (
                                <span className="font-mono text-xs text-muted-foreground">
                                  {product.barcode}
                                </span>
                              ) : (
                                <span className="text-muted-foreground/50">-</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {productCurrency === "IQD" ? "د.ع IQD" : "$ USD"}
                              </Badge>
                            </TableCell>
                            <TableCell>{formatPrice(product.regularPrice, productCurrency)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span>{formatPrice(product.finalPrice, productCurrency)}</span>
                                {discountPercent > 0 && (
                                  <Badge className="bg-primary text-primary-foreground text-xs">
                                    {discountPercent}% OFF
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={product.inStock && product.inStock > 0 ? "outline" : "destructive"}
                              >
                                {product.inStock || 0}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Dialog
                                  open={editingImageProductId === product.id}
                                  onOpenChange={(open) => !open && setEditingImageProductId(null)}
                                >
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => {
                                        setEditingImageProductId(product.id);
                                        setEditingImageUrl(product.imageUrl || "");
                                        if (imageInputRef.current) {
                                          imageInputRef.current.value = "";
                                        }
                                      }}
                                      data-testid={`button-edit-image-${product.id}`}
                                      title="Edit Image"
                                    >
                                      <Image className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[400px]">
                                    <DialogHeader>
                                      <DialogTitle>Edit Product Image</DialogTitle>
                                      <DialogDescription>
                                        Upload a new image for "{product.name}"
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                      {editingImageUrl ? (
                                        <div className="relative w-full h-48 bg-muted rounded-lg overflow-hidden">
                                          <img
                                            src={editingImageUrl}
                                            alt="Product preview"
                                            className="w-full h-full object-cover"
                                          />
                                          <Button
                                            type="button"
                                            variant="destructive"
                                            size="icon"
                                            className="absolute top-2 right-2 h-8 w-8"
                                            onClick={() => setEditingImageUrl("")}
                                            data-testid="button-remove-product-image"
                                          >
                                            <X className="h-4 w-4" />
                                          </Button>
                                        </div>
                                      ) : (
                                        <div
                                          className="w-full h-48 bg-muted rounded-lg border-2 border-dashed border-muted-foreground/25 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
                                          onClick={() => imageInputRef.current?.click()}
                                        >
                                          <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                                          <span className="text-sm text-muted-foreground text-center px-4">
                                            {isUploadingProductImage ? "Uploading..." : "Click to upload new image"}
                                          </span>
                                        </div>
                                      )}
                                      <input
                                        ref={imageInputRef}
                                        type="file"
                                        accept="image/*"
                                        onChange={handleProductImageUpload}
                                        className="hidden"
                                        data-testid="input-product-image-upload"
                                      />
                                      <Button
                                        variant="outline"
                                        className="w-full"
                                        onClick={() => imageInputRef.current?.click()}
                                        disabled={isUploadingProductImage}
                                        data-testid="button-upload-product-image"
                                      >
                                        <Upload className="h-4 w-4 mr-2" />
                                        {isUploadingProductImage ? "Uploading..." : "Choose Image"}
                                      </Button>
                                    </div>
                                    <DialogFooter>
                                      <Button
                                        variant="outline"
                                        onClick={() => setEditingImageProductId(null)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button
                                        onClick={handleSaveProductImage}
                                        disabled={updateProductMutation.isPending}
                                        data-testid="button-save-product-image"
                                      >
                                        {updateProductMutation.isPending ? "Saving..." : "Save Image"}
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <Dialog
                                  open={editingProduct?.id === product.id}
                                  onOpenChange={(open) => !open && setEditingProduct(null)}
                                >
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => setEditingProduct(product)}
                                      data-testid={`button-edit-${product.id}`}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
                                    <DialogHeader>
                                      <DialogTitle>Edit Product</DialogTitle>
                                      <DialogDescription>
                                        Update the product details.
                                      </DialogDescription>
                                    </DialogHeader>
                                    <ProductForm
                                      product={editingProduct || undefined}
                                      onSubmit={(data) =>
                                        updateProductMutation.mutate({ id: product.id, data })
                                      }
                                      onCancel={() => setEditingProduct(null)}
                                      isLoading={updateProductMutation.isPending}
                                    />
                                  </DialogContent>
                                </Dialog>

                                <Dialog
                                  open={deletingProductId === product.id}
                                  onOpenChange={(open) => !open && setDeletingProductId(null)}
                                >
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-destructive hover:text-destructive"
                                      onClick={() => setDeletingProductId(product.id)}
                                      data-testid={`button-delete-${product.id}`}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>Delete Product</DialogTitle>
                                      <DialogDescription>
                                        Are you sure you want to delete "{product.name}"? This action
                                        cannot be undone.
                                      </DialogDescription>
                                    </DialogHeader>
                                    <DialogFooter>
                                      <Button
                                        variant="outline"
                                        onClick={() => setDeletingProductId(null)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button
                                        variant="destructive"
                                        onClick={() => deleteProductMutation.mutate(product.id)}
                                        disabled={deleteProductMutation.isPending}
                                        data-testid="button-confirm-delete"
                                      >
                                        {deleteProductMutation.isPending ? "Deleting..." : "Delete"}
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              );
            })()}
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">User Management</h2>
              <Dialog open={isAddUserDialogOpen} onOpenChange={setIsAddUserDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2" data-testid="button-add-user">
                    <Plus className="h-4 w-4" />
                    Add User
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Add New User</DialogTitle>
                    <DialogDescription>
                      Create a new staff account with username and password.
                    </DialogDescription>
                  </DialogHeader>
                  <UserForm
                    onSubmit={(data) => createUserMutation.mutate(data)}
                    onCancel={() => setIsAddUserDialogOpen(false)}
                    isLoading={createUserMutation.isPending}
                    currentUserId={user.id}
                  />
                </DialogContent>
              </Dialog>
            </div>

            {isLoadingUsers ? (
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : !users || users.length === 0 ? (
              <Card className="max-w-md mx-auto">
                <CardContent className="p-8 flex flex-col items-center text-center space-y-4">
                  <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                    <Users className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold">No Users Yet</h3>
                  <p className="text-muted-foreground">
                    Add staff members to grant access.
                  </p>
                  <Button onClick={() => setIsAddUserDialogOpen(true)} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add User
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Users ({users.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Display Name</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((u) => (
                        <TableRow key={u.id} data-testid={`user-row-${u.id}`}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{u.username}</span>
                              {u.id === user.id && (
                                <Badge variant="outline" className="text-xs">You</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{u.displayName || "-"}</TableCell>
                          <TableCell>
                            <Badge variant={u.role === "owner" ? "default" : "secondary"} className="gap-1">
                              {u.role === "owner" && <Shield className="h-3 w-3" />}
                              {u.role === "owner" ? "Owner" : "Employee"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog
                                open={editingUser?.id === u.id}
                                onOpenChange={(open) => !open && setEditingUser(null)}
                              >
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setEditingUser(u)}
                                    data-testid={`button-edit-user-${u.id}`}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <DialogHeader>
                                    <DialogTitle>Edit User</DialogTitle>
                                    <DialogDescription>
                                      Update user details and permissions.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <UserForm
                                    user={editingUser || undefined}
                                    onSubmit={(data) =>
                                      updateUserMutation.mutate({ id: u.id, data })
                                    }
                                    onCancel={() => setEditingUser(null)}
                                    isLoading={updateUserMutation.isPending}
                                    currentUserId={user.id}
                                  />
                                </DialogContent>
                              </Dialog>

                              <Dialog
                                open={deletingUserId === u.id}
                                onOpenChange={(open) => !open && setDeletingUserId(null)}
                              >
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="text-destructive hover:text-destructive"
                                    onClick={() => setDeletingUserId(u.id)}
                                    disabled={u.id === user.id}
                                    data-testid={`button-delete-user-${u.id}`}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Delete User</DialogTitle>
                                    <DialogDescription>
                                      Are you sure you want to delete "{u.username}"? This action
                                      cannot be undone.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <DialogFooter>
                                    <Button
                                      variant="outline"
                                      onClick={() => setDeletingUserId(null)}
                                    >
                                      Cancel
                                    </Button>
                                    <Button
                                      variant="destructive"
                                      onClick={() => deleteUserMutation.mutate(u.id)}
                                      disabled={deleteUserMutation.isPending}
                                      data-testid="button-confirm-delete-user"
                                    >
                                      {deleteUserMutation.isPending ? "Deleting..." : "Delete"}
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="website" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Website Editing</h2>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Logo
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4">
                    {siteSettings?.logoUrl ? (
                      <div className="h-20 w-20 rounded-lg border border-border overflow-hidden bg-muted flex items-center justify-center">
                        <img
                          src={`${siteSettings.logoUrl}?t=${Date.now()}`}
                          alt="Current logo"
                          className="h-full w-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="h-20 w-20 rounded-lg border border-dashed border-muted-foreground/25 flex items-center justify-center">
                        <Palette className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground mb-2">
                        Upload a new logo for your website. Recommended size: 200x200px
                      </p>
                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                        data-testid="input-logo-upload"
                      />
                      <Button
                        variant="outline"
                        onClick={() => logoInputRef.current?.click()}
                        disabled={isUploadingLogo}
                        className="gap-2"
                        data-testid="button-upload-logo"
                      >
                        <Upload className="h-4 w-4" />
                        {isUploadingLogo ? "Uploading..." : "Upload New Logo"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="h-5 w-5" />
                    Colors
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="primaryColor">Primary Color (Brand)</Label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          id="primaryColor"
                          value={primaryColor}
                          onChange={(e) => setPrimaryColor(e.target.value)}
                          className="h-10 w-14 rounded border border-border cursor-pointer"
                          data-testid="input-primary-color"
                        />
                        <Input
                          value={primaryColor}
                          onChange={(e) => setPrimaryColor(e.target.value)}
                          placeholder="#8B0000"
                          className="flex-1"
                          data-testid="input-primary-color-text"
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="backgroundColor">Background Color</Label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          id="backgroundColor"
                          value={backgroundColor}
                          onChange={(e) => setBackgroundColor(e.target.value)}
                          className="h-10 w-14 rounded border border-border cursor-pointer"
                          data-testid="input-background-color"
                        />
                        <Input
                          value={backgroundColor}
                          onChange={(e) => setBackgroundColor(e.target.value)}
                          placeholder="#0A0A0A"
                          className="flex-1"
                          data-testid="input-background-color-text"
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="accentColor">Accent Color</Label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          id="accentColor"
                          value={accentColor}
                          onChange={(e) => setAccentColor(e.target.value)}
                          className="h-10 w-14 rounded border border-border cursor-pointer"
                          data-testid="input-accent-color"
                        />
                        <Input
                          value={accentColor}
                          onChange={(e) => setAccentColor(e.target.value)}
                          placeholder="#DC2626"
                          className="flex-1"
                          data-testid="input-accent-color-text"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button
                      onClick={handleSaveColors}
                      disabled={updateSettingsMutation.isPending}
                      className="w-full gap-2"
                      data-testid="button-save-colors"
                    >
                      {updateSettingsMutation.isPending ? "Saving..." : "Save Colors"}
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground">
                      Preview your color changes. Colors will be applied across the entire website after saving.
                    </p>
                    <div className="mt-3 flex gap-2">
                      <div
                        className="h-10 w-10 rounded border"
                        style={{ backgroundColor: primaryColor }}
                        title="Primary"
                      />
                      <div
                        className="h-10 w-10 rounded border"
                        style={{ backgroundColor: backgroundColor }}
                        title="Background"
                      />
                      <div
                        className="h-10 w-10 rounded border"
                        style={{ backgroundColor: accentColor }}
                        title="Accent"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t border-border py-6 mt-auto">
        <div className="container mx-auto px-4 md:px-8 text-center text-sm text-muted-foreground space-y-1">
          <p>Created by MatinDex.</p>
          <p>&copy; 2025 iStore. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
