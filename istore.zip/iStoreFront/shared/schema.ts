import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for express-session
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table with roles - preserving varchar id
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default("employee"),
  displayName: varchar("display_name", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users, {
  username: z.string().min(3).max(100),
  password: z.string().min(6),
  role: z.enum(["owner", "employee"]).optional(),
  displayName: z.string().optional(),
}).omit({ id: true });

export const updateUserSchema = z.object({
  username: z.string().min(3).max(100).optional(),
  password: z.string().min(6).optional(),
  role: z.enum(["owner", "employee"]).optional(),
  displayName: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type User = typeof users.$inferSelect;

// Products table for iStore
export const products = pgTable("products", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: varchar("image_url", { length: 500 }),
  category: varchar("category", { length: 100 }),
  barcode: varchar("barcode", { length: 50 }),
  currency: varchar("currency", { length: 3 }).notNull().default("USD"),
  regularPrice: real("regular_price").notNull(),
  finalPrice: real("final_price").notNull(),
  inStock: integer("in_stock").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products, {
  name: z.string().min(1),
  barcode: z.string().optional(),
  currency: z.enum(["USD", "IQD"]).default("USD"),
  regularPrice: z.number().positive(),
  finalPrice: z.number().positive(),
});

export type InsertProduct = typeof products.$inferInsert;
export type Product = typeof products.$inferSelect;

// Currency formatting helpers
export const CURRENCIES = {
  USD: { symbol: "$", name: "US Dollar", code: "USD" },
  IQD: { symbol: "د.ع", name: "Iraqi Dinar", code: "IQD" },
} as const;

export type CurrencyCode = keyof typeof CURRENCIES;

// Site settings table for customization
export const siteSettings = pgTable("site_settings", {
  id: integer("id").primaryKey().default(1),
  logoUrl: varchar("logo_url", { length: 500 }),
  primaryColor: varchar("primary_color", { length: 20 }).default("#8B0000"),
  backgroundColor: varchar("background_color", { length: 20 }).default("#0A0A0A"),
  accentColor: varchar("accent_color", { length: 20 }).default("#DC2626"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const updateSiteSettingsSchema = z.object({
  logoUrl: z.string().optional(),
  primaryColor: z.string().optional(),
  backgroundColor: z.string().optional(),
  accentColor: z.string().optional(),
});

export type SiteSettings = typeof siteSettings.$inferSelect;
export type UpdateSiteSettings = z.infer<typeof updateSiteSettingsSchema>;
