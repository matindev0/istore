import { Express, Request, Response, NextFunction } from "express";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface Request {
      user?: SelectUser;
    }
  }
}

const scryptAsync = promisify(scrypt);

// In-memory token store (token -> userId)
// In production, consider using Redis or database
const tokenStore = new Map<string, { userId: string; expiresAt: number }>();

// Clean up expired tokens periodically
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(tokenStore.entries());
  for (const [token, data] of entries) {
    if (data.expiresAt < now) {
      tokenStore.delete(token);
    }
  }
}, 60 * 1000); // Clean every minute

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

function generateToken(): string {
  return randomBytes(32).toString("hex");
}

export function setupAuth(app: Express) {
  // Token-based authentication - no cookies needed
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePasswords(password, user.password))) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Generate a new token
      const token = generateToken();
      const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
      
      // Store token
      tokenStore.set(token, { userId: user.id, expiresAt });

      // Don't send password to client
      const { password: _, ...safeUser } = user;
      res.status(200).json({ ...safeUser, token });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/logout", (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.substring(7);
      tokenStore.delete(token);
    }
    res.sendStatus(200);
  });

  app.get("/api/user", async (req, res) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const token = authHeader.substring(7);
    const tokenData = tokenStore.get(token);

    if (!tokenData || tokenData.expiresAt < Date.now()) {
      tokenStore.delete(token);
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(tokenData.userId);
    if (!user) {
      tokenStore.delete(token);
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Don't send password to client
    const { password, ...safeUser } = user;
    res.json(safeUser);
  });
}

// Middleware to validate token and attach user to request
async function validateToken(req: Request): Promise<SelectUser | null> {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }

  const token = authHeader.substring(7);
  const tokenData = tokenStore.get(token);

  if (!tokenData || tokenData.expiresAt < Date.now()) {
    tokenStore.delete(token);
    return null;
  }

  const user = await storage.getUser(tokenData.userId);
  return user || null;
}

// Middleware to check if user is authenticated
export async function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  const user = await validateToken(req);
  if (user) {
    req.user = user;
    return next();
  }
  res.status(401).json({ message: "Authentication required" });
}

// Middleware to check if user is an owner
export async function isOwner(req: Request, res: Response, next: NextFunction) {
  const user = await validateToken(req);
  if (user && user.role === "owner") {
    req.user = user;
    return next();
  }
  res.status(403).json({ message: "Owner access required" });
}
