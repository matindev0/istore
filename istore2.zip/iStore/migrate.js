const fs = require('fs');
const path = require('path');
const { Pool } = require('@neondatabase/serverless');

async function migrate() {
  try {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Get all products from PostgreSQL
    const result = await pool.query(`
      SELECT id, name, description, image_url, category, barcode, currency, 
             regular_price, final_price, in_stock, created_at 
      FROM products ORDER BY id ASC
    `);
    
    // Load current database.json
    const dbPath = path.resolve(process.cwd(), 'database.json');
    const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
    
    // Convert PostgreSQL products to JSON format
    const migratedProducts = result.rows.map(row => ({
      id: row.id,
      name: row.name,
      description: row.description || null,
      imageUrl: row.image_url || null,
      category: row.category || null,
      barcode: row.barcode || null,
      currency: row.currency || 'USD',
      regularPrice: parseFloat(row.regular_price),
      finalPrice: parseFloat(row.final_price),
      inStock: row.in_stock || 1,
      createdAt: new Date(row.created_at).toISOString(),
    }));
    
    console.log(`Migrating ${migratedProducts.length} products...`);
    
    // Replace products in database.json
    db.products = migratedProducts;
    
    // Save updated database.json
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2), 'utf-8');
    
    console.log(`✓ Successfully migrated ${migratedProducts.length} products to database.json`);
    await pool.end();
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

migrate();
