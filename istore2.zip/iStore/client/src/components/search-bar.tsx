import { Search, X } from "lucide-react";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function SearchBar({ value, onChange, placeholder = "Search products..." }: SearchBarProps) {
  return (
    <div className="relative w-full max-w-xl flex items-center">
      <Search className="absolute left-4 h-5 w-5 text-muted-foreground pointer-events-none z-10" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-12 pl-12 pr-12 text-base bg-card border border-border rounded-md focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        data-testid="input-search"
      />
      {value && (
        <button
          type="button"
          onClick={() => onChange("")}
          className="absolute right-3 h-8 w-8 flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md"
          data-testid="button-clear-search"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
