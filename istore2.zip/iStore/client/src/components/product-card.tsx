import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, Barcode } from "lucide-react";
import type { Product } from "@shared/schema";
import { formatPrice } from "@shared/currency";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const discountPercent = Math.round(
    ((product.regularPrice - product.finalPrice) / product.regularPrice) * 100
  );
  const currency = product.currency || "USD";

  return (
    <Link href={`/products/${product.id}`}>
      <Card 
        className="overflow-visible hover-elevate product-card-glow cursor-pointer"
        data-testid={`card-product-${product.id}`}
      >
        <CardContent className="p-0">
          <div className="relative aspect-[4/3] bg-muted rounded-t-xl overflow-hidden">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-cover"
                data-testid={`img-product-${product.id}`}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Package className="h-12 w-12 text-muted-foreground/40" />
              </div>
            )}
            
            {discountPercent > 0 && (
              <Badge 
                className="absolute top-3 right-3 bg-primary text-primary-foreground font-bold px-2 py-1"
                data-testid={`badge-discount-${product.id}`}
              >
                {discountPercent}% OFF
              </Badge>
            )}
          </div>

          <div className="p-4 space-y-3">
            {product.category && (
              <span 
                className="text-xs text-muted-foreground uppercase tracking-wider"
                data-testid={`text-category-${product.id}`}
              >
                {product.category}
              </span>
            )}
            
            <h3 
              className="font-semibold text-lg leading-tight line-clamp-2"
              data-testid={`text-name-${product.id}`}
            >
              {product.name}
            </h3>
            
            {product.description && (
              <p 
                className="text-sm text-muted-foreground line-clamp-2"
                data-testid={`text-description-${product.id}`}
              >
                {product.description}
              </p>
            )}
            
            <div className="flex flex-col gap-1 pt-2">
              {product.regularPrice > product.finalPrice && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Regular Price:</span>
                  <span 
                    className="text-sm text-foreground"
                    data-testid={`text-regular-price-${product.id}`}
                  >
                    {formatPrice(product.regularPrice, currency)}
                  </span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Final Price:</span>
                <span 
                  className="text-sm font-bold text-foreground"
                  data-testid={`text-final-price-${product.id}`}
                >
                  {formatPrice(product.finalPrice, currency)}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <span 
                className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                  product.inStock && product.inStock > 0 
                    ? "text-green-400" 
                    : "text-red-400"
                }`}
                data-testid={`text-stock-${product.id}`}
              >
                <span className={`h-2 w-2 rounded-full ${
                  product.inStock && product.inStock > 0 
                    ? "bg-green-400" 
                    : "bg-red-400"
                }`} />
                {product.inStock && product.inStock > 0 ? "In Stock" : "Out of Stock"}
              </span>
            </div>
            
            {product.barcode && (
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Barcode className="h-3 w-3" />
                <span data-testid={`text-barcode-${product.id}`}>{product.barcode}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
