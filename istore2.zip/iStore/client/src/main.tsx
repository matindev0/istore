import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

function clearAllBrowserStorage() {
  // Preserve auth token
  let authToken: string | null = null;
  try {
    authToken = localStorage.getItem("istore_auth_token");
  } catch (e) {
    // localStorage access denied
  }
  
  // Clear localStorage but preserve auth token
  try {
    localStorage.clear();
  } catch (e) {
    // localStorage access denied (private browsing or browser settings)
  }
  
  // Restore auth token if it existed
  if (authToken) {
    try {
      localStorage.setItem("istore_auth_token", authToken);
    } catch (e) {
      // localStorage access denied
    }
  }
  
  try {
    sessionStorage.clear();
  } catch (e) {
    // sessionStorage access denied
  }
  
  try {
    document.cookie.split(";").forEach((cookie) => {
      const eqPos = cookie.indexOf("=");
      const name = eqPos > -1 ? cookie.substring(0, eqPos).trim() : cookie.trim();
      if (name) {
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
      }
    });
  } catch (e) {
    // Cookie access denied
  }
}

clearAllBrowserStorage();

createRoot(document.getElementById("root")!).render(<App />);
