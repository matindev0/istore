import {
  type User,
  type InsertUser,
  type UpdateUser,
  type Product,
  type InsertProduct,
  type SiteSettings,
  type UpdateSiteSettings,
} from "@shared/schema";
import fs from "fs";
import path from "path";
import crypto from "crypto";

// Database file location in project root
const DB_PATH = path.resolve(process.cwd(), "database.json");

interface DatabaseSchema {
  users: User[];
  products: Product[];
  siteSettings: SiteSettings;
}

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, data: UpdateUser): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  countOwners(): Promise<number>;
  
  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Site settings operations
  getSiteSettings(): Promise<SiteSettings | undefined>;
  updateSiteSettings(settings: UpdateSiteSettings): Promise<SiteSettings | undefined>;
}

export class FileStorage implements IStorage {
  private db: DatabaseSchema;
  private nextProductId: number = 1;

  constructor() {
    this.db = this.loadDatabase();
    // Calculate next product ID
    if (this.db.products.length > 0) {
      this.nextProductId = Math.max(...this.db.products.map(p => p.id)) + 1;
    }
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_PATH)) {
        const data = fs.readFileSync(DB_PATH, "utf-8");
        return JSON.parse(data);
      }
    } catch (error) {
      console.error("Error loading database:", error);
    }

    // Return default database structure
    return {
      users: [],
      products: [],
      siteSettings: {
        id: 1,
        logoUrl: null,
        primaryColor: "#8B0000",
        backgroundColor: "#0A0A0A",
        accentColor: "#DC2626",
        updatedAt: new Date(),
      },
    };
  }

  private saveDatabase(): void {
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(this.db, null, 2), "utf-8");
    } catch (error) {
      console.error("Error saving database:", error);
    }
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.db.users.find(u => u.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return this.db.users.find(u => u.username === username);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const user: User = {
      id: crypto.randomUUID(),
      username: userData.username,
      password: userData.password,
      role: userData.role || "employee",
      displayName: userData.displayName || null,
      createdAt: new Date(),
    };
    this.db.users.push(user);
    this.saveDatabase();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return this.db.users.sort((a, b) => {
      const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
      const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
      return aTime - bTime;
    });
  }

  async updateUser(id: string, data: UpdateUser): Promise<User | undefined> {
    const user = this.db.users.find(u => u.id === id);
    if (!user) return undefined;

    if (data.username !== undefined) user.username = data.username;
    if (data.password !== undefined) user.password = data.password;
    if (data.role !== undefined) user.role = data.role;
    if (data.displayName !== undefined) user.displayName = data.displayName;

    this.saveDatabase();
    return user;
  }

  async deleteUser(id: string): Promise<boolean> {
    const index = this.db.users.findIndex(u => u.id === id);
    if (index === -1) return false;
    this.db.users.splice(index, 1);
    this.saveDatabase();
    return true;
  }

  async countOwners(): Promise<number> {
    return this.db.users.filter(u => u.role === "owner").length;
  }

  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return this.db.products.sort((a, b) => {
      const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
      const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
      return aTime - bTime;
    });
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.db.products.find(p => p.id === id);
  }

  async searchProducts(query: string): Promise<Product[]> {
    const q = query.toLowerCase();
    return this.db.products.filter(p => {
      return (
        p.name.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        p.category?.toLowerCase().includes(q) ||
        p.barcode?.toLowerCase().includes(q)
      );
    });
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const newProduct: Product = {
      id: this.nextProductId++,
      name: product.name,
      description: product.description || null,
      imageUrl: product.imageUrl || null,
      category: product.category || null,
      barcode: product.barcode || null,
      currency: product.currency || "USD",
      regularPrice: product.regularPrice,
      finalPrice: product.finalPrice,
      inStock: product.inStock || 1,
      createdAt: new Date(),
    };
    this.db.products.push(newProduct);
    this.saveDatabase();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.db.products.find(p => p.id === id);
    if (!existing) return undefined;

    if (product.name !== undefined) existing.name = product.name;
    if (product.description !== undefined) existing.description = product.description || null;
    if (product.imageUrl !== undefined) existing.imageUrl = product.imageUrl || null;
    if (product.category !== undefined) existing.category = product.category || null;
    if (product.barcode !== undefined) existing.barcode = product.barcode || null;
    if (product.currency !== undefined) existing.currency = product.currency;
    if (product.regularPrice !== undefined) existing.regularPrice = product.regularPrice;
    if (product.finalPrice !== undefined) existing.finalPrice = product.finalPrice;
    if (product.inStock !== undefined) existing.inStock = product.inStock;

    this.saveDatabase();
    return existing;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const index = this.db.products.findIndex(p => p.id === id);
    if (index === -1) return false;
    this.db.products.splice(index, 1);
    this.saveDatabase();
    return true;
  }

  // Site settings operations
  async getSiteSettings(): Promise<SiteSettings | undefined> {
    return this.db.siteSettings;
  }

  async updateSiteSettings(settings: UpdateSiteSettings): Promise<SiteSettings | undefined> {
    if (settings.logoUrl !== undefined) this.db.siteSettings.logoUrl = settings.logoUrl || null;
    if (settings.primaryColor !== undefined) this.db.siteSettings.primaryColor = settings.primaryColor;
    if (settings.backgroundColor !== undefined) this.db.siteSettings.backgroundColor = settings.backgroundColor;
    if (settings.accentColor !== undefined) this.db.siteSettings.accentColor = settings.accentColor;
    this.db.siteSettings.updatedAt = new Date();

    this.saveDatabase();
    return this.db.siteSettings;
  }
}

export const storage = new FileStorage();
