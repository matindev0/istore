export default {
  plugins: {
    'tailwindcss': {},
    'autoprefixer': {},
  },
}

// Suppress PostCSS "from" option warning - it's a known Tailwind+Vite issue with no impact
if (process.env.NODE_ENV !== 'test') {
  const logger = console.log;
  console.log = function(...args) {
    const msg = args.join(' ');
    if (msg.includes('from` option to `postcss.parse')) {
      return;
    }
    logger.apply(console, args);
  };
}
