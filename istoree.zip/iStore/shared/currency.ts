export const CURRENCIES = {
  USD: { symbol: "$", name: "US Dollar", code: "USD" },
  IQD: { symbol: "د.ع", name: "Iraqi Dinar", code: "IQD" },
} as const;

export type CurrencyCode = keyof typeof CURRENCIES;

export function formatPrice(price: number, currency: string): string {
  const curr = CURRENCIES[currency as CurrencyCode] || CURRENCIES.USD;
  if (currency === "IQD") {
    return `${curr.symbol} ${price.toLocaleString()}`;
  }
  return `${curr.symbol}${price.toFixed(2)}`;
}
