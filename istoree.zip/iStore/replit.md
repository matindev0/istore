# iStore - Staff-Only Product Catalog

## Overview
iStore is a private staff-only product catalog for premium electronics and gadgets. The platform features a modern dark theme (black with deep red accents), username/password authentication with role-based access control, product browsing with search and category filtering, and admin product management for owners.

## Current State
- **Staff-Only Catalog**: Complete and functional
- **Authentication**: Username/password login with owner and employee roles
- **Database**: PostgreSQL with products, users, and sessions tables
- **Theme**: Dark theme with black (#0A0A0A) background and deep red (#8B0000) accents

## User Roles
- **owner**: Full access including admin dashboard for product CRUD operations
- **employee**: View-only access to browse products, search, and view details

## Default Accounts
- **Admin Account (owner)**: username: `ahmad`, password: `istore4321`
- **Staff Account (employee)**: username: `istore`, password: `istore1234`

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Token-based authentication with Bearer tokens (no cookies)
- **Token Storage**: localStorage (persists between refreshes)
- **Routing**: Wouter (client-side)
- **Dynamic Theming**: CSS custom properties updated from database-stored colors

## Security Features
- Token-based authentication with Bearer tokens
- Users stay logged in between page refreshes
- Role-based access control for admin features

## Project Structure
```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   │   ├── ui/       # Shadcn UI components
│   │   │   ├── header.tsx
│   │   │   ├── product-card.tsx
│   │   │   ├── product-skeleton.tsx
│   │   │   └── search-bar.tsx
│   │   ├── hooks/        # Custom React hooks
│   │   │   ├── use-auth.tsx
│   │   │   └── use-toast.ts
│   │   ├── lib/          # Utilities
│   │   │   ├── queryClient.ts
│   │   │   └── utils.ts
│   │   ├── pages/        # Page components
│   │   │   ├── admin.tsx    # Product management (owner only)
│   │   │   ├── auth.tsx     # Login page
│   │   │   ├── home.tsx     # Product catalog
│   │   │   ├── product.tsx  # Product details
│   │   │   └── not-found.tsx
│   │   ├── App.tsx
│   │   └── index.css
├── server/                # Backend Express application
│   ├── auth.ts           # Username/password authentication
│   ├── db.ts             # Database connection
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes with role protection
│   ├── seed.ts           # Database seeding (products + owner account)
│   └── storage.ts        # Database operations
└── shared/               # Shared types and schemas
    └── schema.ts         # Drizzle schema definitions
```

## Key Features
1. **Login Page**: Username/password authentication for staff
2. **Home Page**: Product grid with search and category filtering
3. **Product Details**: Full product information with larger images
4. **Admin Dashboard**: Tabbed interface for Products, Users, and Website settings (owners only)
5. **User Management**: Create, edit, delete users with role assignment (owners only)
6. **Website Customization**: Change site colors and logo dynamically (owners only)
7. **Role-Based Access**: Owners have full access; employees can only view

## API Endpoints

### Authentication
- `POST /api/login` - Login with username/password
- `POST /api/logout` - Logout current session
- `GET /api/user` - Get current authenticated user

### Products (requires authentication)
- `GET /api/products` - Get all products
- `GET /api/products/search?q=query` - Search products
- `GET /api/products/:id` - Get single product

### Products Admin (requires owner role)
- `POST /api/products` - Create product
- `PATCH /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product

### Users Admin (requires owner role)
- `GET /api/users` - Get all users (excludes password)
- `POST /api/users` - Create user {username, password, displayName, role}
- `PATCH /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user (prevents self-deletion, ensures at least one owner)

### Site Settings (requires owner role)
- `GET /api/site-settings` - Get current site settings
- `PATCH /api/site-settings` - Update site settings (colors, logo)
- `POST /api/upload-logo` - Upload logo image

## Database Schema
- **users**: id (varchar UUID), username, password (hashed), role, displayName, createdAt
- **products**: id, name, description, imageUrl, category, barcode, currency (USD/IQD), regularPrice, finalPrice, inStock, createdAt
- **sessions**: sid, sess, expire (for session management)
- **site_settings**: id, logoUrl, primaryColor, backgroundColor, accentColor, updatedAt

## Barcode Support
- Products can have an optional barcode field
- Search functionality includes barcode matching - search by barcode to find products
- Barcodes are displayed on product cards and product detail pages
- Admin product form includes barcode input field

## Currency Support
Products support two currencies:
- **USD**: US Dollar ($) - prices displayed with 2 decimal places
- **IQD**: Iraqi Dinar (د.ع) - prices displayed with locale formatting (thousands separators)

Currency is selected before entering prices in the product form. The currency symbol is displayed consistently across:
- Product cards on home page
- Product detail pages
- Admin product management table

## Development Commands
- `npm run dev` - Start development server
- `npm run db:push` - Push schema changes to database

## Recent Changes (December 2024)
- Added dual currency support (USD and IQD) with currency-first selection in product forms
- Currency displayed with appropriate symbols ($, د.ع) and formatting across all views
- Added user management feature with create, edit, delete functionality (owners only)
- Admin dashboard now uses tabbed interface for Products, Users, and Website settings
- User management includes role assignment, prevents self-deletion, ensures at least one owner exists
- Replaced Replit Auth with username/password authentication
- Added owner and employee roles with role-based access control
- Removed cart, checkout, and ordering functionality (staff-only catalog)
- Created admin dashboard for product CRUD operations (owner only)
- Added product detail pages with full descriptions
- Dark theme with deep red accents throughout
- Product catalog with 12 sample products seeded
- PWA support for installable app experience
- Added website customization feature allowing owners to change site colors and logo dynamically
- Token storage moved to localStorage so users stay logged in between page refreshes
