# iStore E-Commerce Design Guidelines

## Design Approach
**Reference-Based Approach** drawing from modern e-commerce platforms (Shopify, Nike, Apple Store) adapted for a bold dark aesthetic. The design prioritizes product showcase with dramatic contrast and premium feel.

## Core Design Elements

### Typography
- **Headings**: Inter or Montserrat (600-700 weight) for product names and section titles
- **Body**: Inter or System UI (400-500 weight) for descriptions and UI text
- **Pricing**: Display font sizes prominently - Regular price at text-base, Final price at text-xl to text-2xl (bold)
- **Hierarchy**: Large hero text (text-4xl to text-6xl), section headings (text-2xl to text-3xl), product cards (text-lg to text-xl)

### Layout System
**Tailwind Spacing Units**: Primary units of 4, 6, 8, 12, 16, 24
- Container padding: px-4 md:px-8 lg:px-16
- Section spacing: py-12 md:py-16 lg:py-24
- Card spacing: p-4 to p-6
- Grid gaps: gap-6 to gap-8

### Color Implementation
**Base Colors** (User-Specified):
- Background: Black (#000000) or near-black (#0A0A0A)
- Deep Red Accents: #8B0000 to #B91C1C for CTAs, badges, hover states, active elements
- Supporting: Dark gray (#1A1A1A) for cards/containers, mid-gray (#404040) for borders
- Text: White (#FFFFFF) primary, light gray (#D1D1D1) secondary

## Component Library

### Authentication
- **Login Screen**: Centered card (max-w-md) with deep red gradient border, frosted dark background
- Form inputs with subtle red underline on focus
- Primary CTA button: Deep red background with white text

### Product Grid
- **Layout**: Grid with 2 columns (md:grid-cols-3, lg:grid-cols-4)
- **Product Cards**: Dark gray background (#1A1A1A), subtle border, hover effect with red glow
- Product image at top (aspect-square), name below
- **Dual Pricing Display**: 
  - Regular price: Small, light gray, line-through (text-sm text-gray-400)
  - Final price: Large, white, bold (text-2xl font-bold)
  - Discount badge: Absolute positioned top-right, red background, white text showing "X% OFF"

### Search Section
- **Sticky header bar**: Dark background with red accent line at bottom
- Large search input (h-12 to h-14) with red focus ring
- Real-time filtering with smooth transitions
- Search icon from Heroicons (magnifying-glass)

### Navigation
- **Top bar**: Horizontal layout with logo left, search center, user/cart icons right
- Logo: "iStore" in bold with red accent underline or icon
- Icons: Heroicons (shopping-cart, user-circle) in white, red on hover

### Interactive Elements
- **Buttons**: Deep red primary (#8B0000), darker red hover (#6B0000)
- **Cards**: Transform on hover (scale-105), red border glow effect
- **Links**: White text, red underline on hover
- **Badges**: Red pill-shaped discount indicators

## Images
**Product Images Required**:
- High-quality product photos on transparent or pure black backgrounds
- Square aspect ratio (1:1) for grid consistency
- Minimum 800x800px resolution
- Place in each product card with object-cover

**No Hero Image**: Skip traditional hero - lead directly with featured product grid or spotlight carousel for immediate product focus, maintaining e-commerce efficiency

## Layout Structure
1. **Header/Navigation**: Sticky top bar (h-16 to h-20)
2. **Search Bar**: Prominent below header or integrated
3. **Product Grid**: Main content area with 8-16 products visible
4. **Product Cards**: Image, name, dual pricing, discount badge, "Add to Cart" CTA

## Key Principles
- **High Contrast**: White text on black backgrounds for readability
- **Red as Power Color**: Use sparingly for CTAs, prices, and key interactions
- **Product-First**: Minimal decorative elements, focus on product imagery and pricing
- **Premium Feel**: Clean spacing, bold typography, sophisticated dark aesthetic
- **Scannable Pricing**: Make discounted prices immediately obvious with size and positioning