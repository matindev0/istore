import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Home, Store } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border py-4">
        <div className="container mx-auto px-4 md:px-8">
          <a href="/" className="flex items-center gap-2 w-fit" data-testid="link-home">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary">
              <Store className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold tracking-tight">
              i<span className="text-primary">Store</span>
            </span>
          </a>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 flex flex-col items-center text-center space-y-6">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-bold" data-testid="text-404-title">404</h1>
              <p className="text-xl font-semibold text-foreground">Page Not Found</p>
              <p className="text-muted-foreground">
                The page you're looking for doesn't exist or has been moved.
              </p>
            </div>
            <Button asChild data-testid="button-go-home">
              <a href="/" className="gap-2">
                <Home className="h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
