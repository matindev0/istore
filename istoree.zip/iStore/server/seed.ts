import { storage } from "./storage";
import { hashPassword } from "./auth";

const sampleProducts = [
  {
    name: "iPhone 15 Pro Max",
    description: "The most powerful iPhone ever with titanium design, A17 Pro chip, and advanced camera system",
    imageUrl: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&h=800&fit=crop",
    category: "Smartphones",
    regularPrice: 1199.99,
    finalPrice: 999.99,
    inStock: 15,
    currency: "USD",
  },
  {
    name: "MacBook Pro 16\" M3 Max",
    description: "Supercharged by M3 Max with up to 128GB unified memory and stunning Liquid Retina XDR display",
    imageUrl: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&h=800&fit=crop",
    category: "Laptops",
    regularPrice: 3499.99,
    finalPrice: 2999.99,
    inStock: 8,
    currency: "USD",
  },
  {
    name: "AirPods Pro 2nd Gen",
    description: "Rebuilt from the sound up with Adaptive Audio, USB-C charging, and up to 6 hours battery life",
    imageUrl: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800&h=800&fit=crop",
    category: "Audio",
    regularPrice: 249.99,
    finalPrice: 199.99,
    inStock: 50,
    currency: "USD",
  },
  {
    name: "Apple Watch Ultra 2",
    description: "The most rugged and capable Apple Watch with precision dual-frequency GPS and 36-hour battery",
    imageUrl: "https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?w=800&h=800&fit=crop",
    category: "Wearables",
    regularPrice: 799.99,
    finalPrice: 699.99,
    inStock: 12,
    currency: "USD",
  },
  {
    name: "iPad Pro 12.9\" M2",
    description: "The ultimate iPad experience with M2 chip, Liquid Retina XDR display, and Apple Pencil hover",
    imageUrl: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=800&h=800&fit=crop",
    category: "Tablets",
    regularPrice: 1099.99,
    finalPrice: 899.99,
    inStock: 20,
    currency: "USD",
  },
  {
    name: "Samsung Galaxy S24 Ultra",
    description: "AI-powered smartphone with titanium frame, 200MP camera, and Galaxy AI features",
    imageUrl: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&h=800&fit=crop",
    category: "Smartphones",
    regularPrice: 1299.99,
    finalPrice: 1099.99,
    inStock: 18,
    currency: "USD",
  },
  {
    name: "Sony WH-1000XM5",
    description: "Industry-leading noise cancellation with 30-hour battery and crystal-clear hands-free calling",
    imageUrl: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=800&h=800&fit=crop",
    category: "Audio",
    regularPrice: 399.99,
    finalPrice: 299.99,
    inStock: 30,
    currency: "USD",
  },
  {
    name: "DJI Mini 4 Pro",
    description: "Under 249g drone with 4K/60fps HDR video, omnidirectional obstacle sensing, and 34min flight",
    imageUrl: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=800&h=800&fit=crop",
    category: "Drones",
    regularPrice: 759.99,
    finalPrice: 649.99,
    inStock: 5,
    currency: "USD",
  },
  {
    name: "Nintendo Switch OLED",
    description: "Vivid 7-inch OLED screen, enhanced audio, and wide adjustable stand for gaming anywhere",
    imageUrl: "https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=800&h=800&fit=crop",
    category: "Gaming",
    regularPrice: 349.99,
    finalPrice: 299.99,
    inStock: 25,
    currency: "USD",
  },
  {
    name: "Canon EOS R5",
    description: "Full-frame mirrorless camera with 45MP sensor, 8K video, and advanced autofocus system",
    imageUrl: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=800&fit=crop",
    category: "Cameras",
    regularPrice: 3899.99,
    finalPrice: 3299.99,
    inStock: 4,
    currency: "USD",
  },
  {
    name: "LG C3 65\" OLED TV",
    description: "Self-lit OLED pixels, a9 AI Processor Gen6, and Dolby Vision & Atmos for ultimate entertainment",
    imageUrl: "https://images.unsplash.com/photo-1593784991095-a205069470b6?w=800&h=800&fit=crop",
    category: "TVs",
    regularPrice: 1799.99,
    finalPrice: 1399.99,
    inStock: 6,
    currency: "USD",
  },
  {
    name: "Bose QuietComfort Ultra",
    description: "World-class noise cancellation with immersive audio and CustomTune sound calibration",
    imageUrl: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&h=800&fit=crop",
    category: "Audio",
    regularPrice: 429.99,
    finalPrice: 349.99,
    inStock: 22,
    currency: "USD",
  },
];

export async function seedProducts() {
  try {
    const existingProducts = await storage.getAllProducts();
    
    if (existingProducts.length === 0) {
      console.log("Seeding products...");
      for (const product of sampleProducts) {
        await storage.createProduct(product);
      }
      console.log(`Seeded ${sampleProducts.length} products successfully`);
    } else {
      console.log(`Products already exist (${existingProducts.length} found), skipping seed`);
    }
  } catch (error) {
    console.error("Error seeding products:", error);
  }
}

export async function seedUsers() {
  try {
    const existingUsers = await storage.getAllUsers();
    
    if (existingUsers.length === 0) {
      console.log("Creating user accounts...");
      
      // Create admin account (owner role)
      const adminPassword = await hashPassword("istore4321");
      await storage.createUser({
        username: "ahmad",
        password: adminPassword,
        role: "owner",
        displayName: "Ahmad",
      });
      console.log("Admin account created (username: ahmad)");
      
      // Create employee account
      const employeePassword = await hashPassword("istore1234");
      await storage.createUser({
        username: "istore",
        password: employeePassword,
        role: "employee",
        displayName: "iStore Staff",
      });
      console.log("Employee account created (username: istore)");
    } else {
      console.log("Users already exist, skipping user seed");
    }
  } catch (error) {
    console.error("Error seeding users:", error);
  }
}
