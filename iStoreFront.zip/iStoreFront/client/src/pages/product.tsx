import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Header } from "@/components/header";
import { useAuth } from "@/hooks/use-auth";
import type { Product } from "@shared/schema";
import { formatPrice } from "@shared/currency";
import { Package, ArrowLeft, Check, Barcode } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

function ProductDetailSkeleton() {
  return (
    <div className="grid md:grid-cols-2 gap-8">
      <Skeleton className="aspect-square rounded-xl" />
      <div className="space-y-6">
        <Skeleton className="h-6 w-24" />
        <Skeleton className="h-10 w-3/4" />
        <Skeleton className="h-24 w-full" />
        <div className="flex gap-4">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-6 w-24" />
        </div>
      </div>
    </div>
  );
}

export default function ProductPage() {
  const { user } = useAuth();
  const [, params] = useRoute("/products/:id");
  const productId = params?.id;

  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: ["/api/products", productId],
    enabled: !!productId,
  });

  if (!user) return null;

  const discountPercent = product 
    ? Math.round(((product.regularPrice - product.finalPrice) / product.regularPrice) * 100)
    : 0;
  const currency = product?.currency || "USD";

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header user={user} />
      
      <main className="flex-1 container mx-auto px-4 md:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Products
          </Button>
        </Link>

        {isLoading ? (
          <ProductDetailSkeleton />
        ) : error || !product ? (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-8 flex flex-col items-center text-center space-y-4">
              <div className="h-14 w-14 rounded-full bg-destructive/10 flex items-center justify-center">
                <Package className="h-7 w-7 text-destructive" />
              </div>
              <h3 className="text-xl font-semibold">Product Not Found</h3>
              <p className="text-muted-foreground">
                The product you're looking for doesn't exist or has been removed.
              </p>
              <Link href="/">
                <Button data-testid="button-browse">Browse Products</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            <div className="relative aspect-square bg-muted rounded-xl overflow-hidden">
              {product.imageUrl ? (
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  data-testid="img-product-detail"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-24 w-24 text-muted-foreground/40" />
                </div>
              )}
              
              {discountPercent > 0 && (
                <Badge 
                  className="absolute top-4 right-4 bg-primary text-primary-foreground font-bold px-3 py-1.5 text-base"
                  data-testid="badge-discount-detail"
                >
                  {discountPercent}% OFF
                </Badge>
              )}
            </div>

            <div className="flex flex-col space-y-6">
              {product.category && (
                <Badge variant="outline" className="w-fit" data-testid="badge-category-detail">
                  {product.category}
                </Badge>
              )}
              
              <h1 
                className="text-3xl md:text-4xl font-bold tracking-tight"
                data-testid="text-product-name"
              >
                {product.name}
              </h1>
              
              {product.description && (
                <p 
                  className="text-lg text-muted-foreground leading-relaxed"
                  data-testid="text-product-description"
                >
                  {product.description}
                </p>
              )}
              
              <div className="flex flex-col gap-2 py-4 border-y border-border">
                {product.regularPrice > product.finalPrice && (
                  <div className="flex items-center gap-3">
                    <span className="text-lg text-muted-foreground">Regular Price:</span>
                    <span 
                      className="text-lg text-foreground"
                      data-testid="text-product-regular-price"
                    >
                      {formatPrice(product.regularPrice, currency)}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <span className="text-lg text-muted-foreground">Final Price:</span>
                  <span 
                    className="text-lg font-bold text-foreground"
                    data-testid="text-product-final-price"
                  >
                    {formatPrice(product.finalPrice, currency)}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <span 
                  className={`inline-flex items-center gap-2 text-sm font-medium ${
                    product.inStock && product.inStock > 0 
                      ? "text-green-400" 
                      : "text-red-400"
                  }`}
                  data-testid="text-product-stock"
                >
                  <span className={`h-2.5 w-2.5 rounded-full ${
                    product.inStock && product.inStock > 0 
                      ? "bg-green-400" 
                      : "bg-red-400"
                  }`} />
                  {product.inStock && product.inStock > 0 
                    ? `In Stock (${product.inStock} available)` 
                    : "Out of Stock"}
                </span>
              </div>
              
              {product.barcode && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Barcode className="h-4 w-4" />
                  <span>Barcode:</span>
                  <span 
                    className="font-mono text-foreground"
                    data-testid="text-product-barcode"
                  >
                    {product.barcode}
                  </span>
                </div>
              )}
              
              <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="h-4 w-4 text-green-400" />
                  <span>Staff-only product catalog</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="h-4 w-4 text-green-400" />
                  <span>View pricing and stock levels</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="h-4 w-4 text-green-400" />
                  <span>Premium electronics collection</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-border py-6 mt-auto">
        <div className="container mx-auto px-4 md:px-8 text-center text-sm text-muted-foreground space-y-1">
          <p>Created by MatinDex.</p>
          <p>&copy; 2025 iStore. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
