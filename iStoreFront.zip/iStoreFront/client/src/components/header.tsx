import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LogOut, User, Settings, Shield, Store } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import type { User as UserType, SiteSettings } from "@shared/schema";

interface HeaderProps {
  user: UserType;
}

export function Header({ user }: HeaderProps) {
  const { logoutMutation } = useAuth();
  
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });
  
  const initials = user.displayName?.[0]?.toUpperCase() || 
                   user.username?.[0]?.toUpperCase() || "U";

  const displayName = user.displayName || user.username || "User";
  const isOwner = user.role === "owner";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const logoUrl = siteSettings?.logoUrl 
    ? `${siteSettings.logoUrl}?t=${siteSettings.updatedAt ? new Date(siteSettings.updatedAt).getTime() : Date.now()}`
    : `/logo.png?t=${Date.now()}`;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between gap-4 px-4 md:px-8">
        <Link href="/" className="flex items-center gap-2 shrink-0" data-testid="link-home">
          {siteSettings?.logoUrl ? (
            <img src={logoUrl} alt="iStore" className="h-12 w-12 object-contain" />
          ) : (
            <Store className="h-10 w-10 text-primary" />
          )}
          <span className="text-2xl font-bold tracking-tight hidden sm:inline">
            i<span className="text-primary">Store</span>
          </span>
        </Link>

        <div className="flex items-center gap-2">
          {isOwner && (
            <Link href="/admin">
              <Button 
                variant="ghost" 
                size="icon"
                data-testid="button-admin"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </Link>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center gap-3 px-2"
                data-testid="button-user-menu"
              >
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden md:inline text-sm font-medium" data-testid="text-user-name">
                  {displayName}
                </span>
                {isOwner && (
                  <Badge variant="secondary" className="hidden sm:flex gap-1 text-xs">
                    <Shield className="h-3 w-3" />
                    Owner
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{displayName}</p>
                  <p className="text-xs leading-none text-muted-foreground capitalize">
                    {user.role}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2" disabled>
                <User className="h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="gap-2 text-destructive focus:text-destructive cursor-pointer"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
