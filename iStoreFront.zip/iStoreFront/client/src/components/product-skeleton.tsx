import { Card, CardContent } from "@/components/ui/card";

export function ProductSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        {/* Image Skeleton */}
        <div className="aspect-square bg-muted shimmer" />
        
        {/* Content Skeleton */}
        <div className="p-4 space-y-3">
          {/* Category */}
          <div className="h-3 w-16 bg-muted rounded shimmer" />
          
          {/* Name */}
          <div className="space-y-2">
            <div className="h-5 w-full bg-muted rounded shimmer" />
            <div className="h-5 w-2/3 bg-muted rounded shimmer" />
          </div>
          
          {/* Description */}
          <div className="h-4 w-full bg-muted rounded shimmer" />
          
          {/* Price */}
          <div className="flex items-baseline gap-3 pt-2">
            <div className="h-7 w-20 bg-muted rounded shimmer" />
            <div className="h-4 w-14 bg-muted rounded shimmer" />
          </div>
          
          {/* Stock */}
          <div className="h-4 w-16 bg-muted rounded shimmer" />
        </div>
      </CardContent>
    </Card>
  );
}

export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <ProductSkeleton key={i} />
      ))}
    </div>
  );
}
