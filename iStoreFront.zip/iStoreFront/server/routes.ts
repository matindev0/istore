import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isOwner, hashPassword } from "./auth";
import { insertProductSchema, insertUserSchema, updateUserSchema, updateSiteSettingsSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import expressStatic from "express";
import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

// Use absolute path for item images directory to ensure persistence across restarts
const uploadDir = path.resolve(process.cwd(), "item images");

// Ensure item images directory exists with proper permissions (non-blocking)
const ensureUploadDir = () => {
  try {
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true, mode: 0o755 });
    }
  } catch (error) {
    // Silently fail - directory may already exist or be read-only
    // Uploads will still work if the directory is already set up
  }
};

// Try to create directory on startup
ensureUploadDir();

const imageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: imageStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth middleware - must be set up first
  setupAuth(app);

  // Serve uploaded files
  app.use("/item-images", expressStatic.static(uploadDir));

  // Image upload endpoint - owner only
  app.post("/api/upload", isOwner, upload.single("image"), (req: any, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No image file provided" });
    }
    const imageUrl = `/item-images/${req.file.filename}`;
    res.json({ imageUrl });
  });

  // Barcode lookup with AI - owner only
  app.post("/api/barcode-lookup", isOwner, async (req: any, res) => {
    try {
      const { barcode } = req.body;
      if (!barcode || typeof barcode !== "string") {
        return res.status(400).json({ message: "Barcode is required" });
      }

      let productInfo: { name?: string; description?: string; imageUrl?: string; category?: string } = {};

      // First, try UPCitemdb free trial API
      try {
        const upcResponse = await fetch(
          `https://api.upcitemdb.com/prod/trial/lookup?upc=${encodeURIComponent(barcode)}`,
          {
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
          }
        );

        if (upcResponse.ok) {
          const upcData = await upcResponse.json();
          if (upcData.items && upcData.items.length > 0) {
            const item = upcData.items[0];
            productInfo.name = item.title || item.brand || "";
            productInfo.description = item.description || "";
            productInfo.category = item.category || "";
            // Get the first image if available
            if (item.images && item.images.length > 0) {
              productInfo.imageUrl = item.images[0];
            }
          }
        }
      } catch (upcError) {
        console.log("UPCitemdb lookup failed, falling back to AI:", upcError);
      }

      // If no product found or no image, use AI to generate description and image
      if (!productInfo.name || !productInfo.imageUrl) {
        try {
          // Use AI to generate product description based on barcode
          const aiResponse = await openai.chat.completions.create({
            model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025
            messages: [
              {
                role: "system",
                content: "You are a product database assistant. Given a barcode, provide plausible product information. Respond in JSON format with fields: name, description, category. Make educated guesses based on barcode patterns if needed."
              },
              {
                role: "user",
                content: `Barcode: ${barcode}. What product could this be? Provide name, description, and category.`
              }
            ],
            response_format: { type: "json_object" },
            max_completion_tokens: 500,
          });

          const aiContent = aiResponse.choices[0]?.message?.content;
          if (aiContent) {
            const aiData = JSON.parse(aiContent);
            if (!productInfo.name) productInfo.name = aiData.name || `Product ${barcode}`;
            if (!productInfo.description) productInfo.description = aiData.description || "";
            if (!productInfo.category) productInfo.category = aiData.category || "";
          }
        } catch (aiError) {
          console.log("AI description generation failed:", aiError);
          if (!productInfo.name) productInfo.name = `Product ${barcode}`;
        }

        // Generate image with AI if no image found
        if (!productInfo.imageUrl && productInfo.name) {
          try {
            const imageResponse = await openai.images.generate({
              model: "gpt-image-1",
              prompt: `Professional product photo of ${productInfo.name}, ${productInfo.category || "electronics"}, white background, commercial photography, high quality`,
              size: "1024x1024",
            });

            const base64Image = imageResponse.data[0]?.b64_json;
            if (base64Image) {
              // Save the generated image to item images directory
              const imageBuffer = Buffer.from(base64Image, "base64");
              const filename = `${Date.now()}-${Math.round(Math.random() * 1e9)}.png`;
              const imagePath = path.join(uploadDir, filename);
              fs.writeFileSync(imagePath, imageBuffer);
              productInfo.imageUrl = `/item-images/${filename}`;
            }
          } catch (imageError) {
            console.log("AI image generation failed:", imageError);
            // Use a generic product image as fallback
            productInfo.imageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop";
          }
        }
      }

      res.json({
        success: true,
        barcode,
        ...productInfo,
      });
    } catch (error) {
      console.error("Error in barcode lookup:", error);
      res.status(500).json({ message: "Failed to lookup barcode" });
    }
  });

  // Product routes - protected (all staff can view)
  app.get("/api/products", isAuthenticated, async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/search", isAuthenticated, async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        const products = await storage.getAllProducts();
        return res.json(products);
      }
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      console.error("Error searching products:", error);
      res.status(500).json({ message: "Failed to search products" });
    }
  });

  app.get("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      const product = await storage.getProductById(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Admin product management routes - owner only
  app.post("/api/products", isOwner, async (req: any, res) => {
    try {
      const result = insertProductSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid product data", errors: result.error.errors });
      }
      const product = await storage.createProduct(result.data);
      res.status(201).json(product);
    } catch (error) {
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", isOwner, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      const product = await storage.updateProduct(id, req.body);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", isOwner, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // User management routes - owner only
  app.get("/api/users", isOwner, async (req: any, res) => {
    try {
      const users = await storage.getAllUsers();
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users", isOwner, async (req: any, res) => {
    try {
      const result = insertUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid user data", errors: result.error.errors });
      }
      
      const existingUser = await storage.getUserByUsername(result.data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const hashedPassword = await hashPassword(result.data.password);
      const user = await storage.createUser({
        ...result.data,
        password: hashedPassword,
      });
      
      const { password, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", isOwner, async (req: any, res) => {
    try {
      const { id } = req.params;
      const currentUser = req.user;
      
      const result = updateUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid user data", errors: result.error.errors });
      }
      
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (result.data.role === "employee" && targetUser.role === "owner") {
        const ownerCount = await storage.countOwners();
        if (ownerCount <= 1) {
          return res.status(400).json({ message: "Cannot demote the last owner" });
        }
      }
      
      if (result.data.username && result.data.username !== targetUser.username) {
        const existingUser = await storage.getUserByUsername(result.data.username);
        if (existingUser) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      const updateData: any = { ...result.data };
      if (updateData.password) {
        updateData.password = await hashPassword(updateData.password);
      }
      
      const user = await storage.updateUser(id, updateData);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", isOwner, async (req: any, res) => {
    try {
      const { id } = req.params;
      const currentUser = req.user;
      
      if (id === currentUser.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (targetUser.role === "owner") {
        const ownerCount = await storage.countOwners();
        if (ownerCount <= 1) {
          return res.status(400).json({ message: "Cannot delete the last owner" });
        }
      }
      
      await storage.deleteUser(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Site settings routes - public GET, owner-only updates
  app.get("/api/site-settings", async (req, res) => {
    try {
      const settings = await storage.getSiteSettings();
      res.json(settings || {
        id: 1,
        logoUrl: "/logo.png",
        primaryColor: "#8B0000",
        backgroundColor: "#0A0A0A",
        accentColor: "#DC2626",
      });
    } catch (error) {
      console.error("Error fetching site settings:", error);
      res.status(500).json({ message: "Failed to fetch site settings" });
    }
  });

  app.patch("/api/site-settings", isOwner, async (req: any, res) => {
    try {
      const result = updateSiteSettingsSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid settings data", errors: result.error.errors });
      }
      const settings = await storage.updateSiteSettings(result.data);
      res.json(settings);
    } catch (error) {
      console.error("Error updating site settings:", error);
      res.status(500).json({ message: "Failed to update site settings" });
    }
  });

  // Logo upload endpoint - owner only
  app.post("/api/upload-logo", isOwner, upload.single("logo"), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No logo file provided" });
      }
      const logoUrl = `/item-images/${req.file.filename}`;
      const settings = await storage.updateSiteSettings({ logoUrl });
      res.json({ logoUrl, settings });
    } catch (error) {
      console.error("Error uploading logo:", error);
      res.status(500).json({ message: "Failed to upload logo" });
    }
  });

  return httpServer;
}
